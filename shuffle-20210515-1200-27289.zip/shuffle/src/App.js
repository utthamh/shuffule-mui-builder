import React from 'react';
import {
  BrowserRouter as Router,
  Switch,
  Route
} from 'react-router-dom';

import IndexPage from './pages/Index.js';
import CookiesPage from './pages/Cookies.js';
import FootersPage from './pages/Footers.js';

export default function App() {
  return (
    <Router>
        <Switch>
          <Route exact path="/">
            <IndexPage />
          </Route>
          <Route exact path="/cookies">
            <CookiesPage />
          </Route>
          <Route exact path="/footers">
            <FootersPage />
          </Route>
        </Switch>
    </Router>
  );
}
