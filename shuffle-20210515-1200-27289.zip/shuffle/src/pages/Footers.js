import React from 'react';

import Footer2 from '../components/footers/Footer2';
import Footer1 from '../components/footers/Footer1';

export default function Footers() {
  return (
    <React.Fragment>
      <Footer2 content={null} />

      <Footer1 content={null} />
    </React.Fragment>
  );
}

