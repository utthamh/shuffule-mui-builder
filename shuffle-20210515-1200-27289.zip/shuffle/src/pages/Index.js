import React from 'react';

import HorizontalNav2 from '../components/horizontal-navs/HorizontalNav2';
import ElementParagraph from '../components/__elements/ElementParagraph';
import Team2 from '../components/team/Team2';
import Team1 from '../components/team/Team1';
import Blog2 from '../components/blog/Blog2';
import Header1 from '../components/headers/Header1';
import HowItWorks2 from '../components/how-it-works/HowItWorks2';
import Blog1 from '../components/blog/Blog1';
import HowItWorks1 from '../components/how-it-works/HowItWorks1';
import Portfolio2 from '../components/portfolio/Portfolio2';
import Portfolio1 from '../components/portfolio/Portfolio1';
import Content2 from '../components/content/Content2';
import Content1 from '../components/content/Content1';
import Pricing2 from '../components/pricing/Pricing2';
import Pricing1 from '../components/pricing/Pricing1';
import Contact1 from '../components/contacts/Contact1';
import Contact2 from '../components/contacts/Contact2';
import Testimonials1 from '../components/testimonials/Testimonials1';
import Testimonials2 from '../components/testimonials/Testimonials2';
import CallToAction2 from '../components/call-to-action/CallToAction2';
import CallToAction1 from '../components/call-to-action/CallToAction1';
import SignIn2 from '../components/sign-in/SignIn2';

export default function Index() {
  return (
    <React.Fragment>
      <HorizontalNav2 content={null} />

      <ElementParagraph content={null} />

      <Team2 content={null} />

      <Team1 content={null} />

      <Blog2 content={null} />

      <Header1 content={null} />

      <HowItWorks2 content={null} />

      <Blog1 content={null} />

      <HowItWorks1 content={null} />

      <Portfolio2 content={null} />

      <Portfolio1 content={null} />

      <Content2 content={null} />

      <Content1 content={null} />

      <Pricing2 content={null} />

      <Pricing1 content={null} />

      <Contact1 content={null} />

      <Contact2 content={null} />

      <Testimonials1 content={null} />

      <Testimonials2 content={null} />

      <CallToAction2 content={null} />

      <CallToAction1 content={null} />

      <SignIn2
        content={{
          header: 'jdjd',
        }}
      />
    </React.Fragment>
  );
}

