import React from 'react';

import Cookies1 from '../components/cookies/Cookies1';
import Cookies2 from '../components/cookies/Cookies2';

export default function Cookies() {
  return (
    <React.Fragment>
      <Cookies1 content={null} />

      <Cookies2 content={null} />
    </React.Fragment>
  );
}

